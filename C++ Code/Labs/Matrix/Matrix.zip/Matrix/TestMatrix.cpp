#include <iostream>   // cout
#include <random>
#include <vector>
#include <iterator>

#include "TestMatrix.h"
#include "matrix.h"

//using namespace MatrixM


void RunTests() {
	TestMatrix();
}

int TestMatrix() {
	MatrixM::Matrix m;

	//std::cout << "Matrix size is" << m1 << m.GetRows() << "x" << m.GetCols() << std::endl;
	return 0;
}