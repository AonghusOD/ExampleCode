#pragma once

#include "matrix.h"
#ifndef TESTMATRIX
#define TESTMATRIX

void RunTests();
int TestMatrix();

#endif