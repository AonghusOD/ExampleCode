#include "matrix.h"
#include "TestMatrix.h"

int main() {

	RunTests();
	return 0;
}