#include <iostream>
#include "team.h"
#include "..\Programmer\Programmer.h"



int main() {

	/*team t;

	Programmer p;

	t.AddProgrammer(p);*/

	return 0;
}
