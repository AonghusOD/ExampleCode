#include "Programmer.h"


#include <iostream>		// cout, endl
#include <vector>		// vector
#include <string>		

Programmer::Programmer() {

#if VERBOSE
	std::cout << "Default constructor" << std::endl;
#endif

	name = 'Anon';
	level = 3;
}

