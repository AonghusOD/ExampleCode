#include "Programmer.h"

int main(){

	Programmer p1; //Instantiates an object, p1, of the class programmer, via default constructor

	return 0;
}