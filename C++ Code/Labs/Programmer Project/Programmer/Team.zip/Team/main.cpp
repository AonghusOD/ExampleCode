#include <iostream>
#include "team.h"
#include "..\Programmer\Programmer.h"



int main() {

	/*Team t;

	Programmer p;

	t.AddProgrammer(p);*/

	return 0;
}
