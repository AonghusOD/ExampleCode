/*Aonghus O Domhnaill
 * G00293306
 * Lab Exam 2021
 * Adding data to MySQL Database
 */

import java.awt.*;
import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class AddBook extends JFrame {
    // references to prepared statements for inserting entry
    private PreparedStatement sqlInsertbooks;

    public AddBook() {
        super("Books");

        Container c = getContentPane();

        c.add(new JLabel("First Name"));
        JTextField firstName = new JTextField(5);
        c.add(firstName);

        c.add(new JLabel("Last Name"));
        JTextField lastName = new JTextField(5);
        c.add(lastName);

        c.add(new JLabel("ISBN"));
        JTextField isbn = new JTextField(5);
        c.add(isbn);

        c.add(new JLabel("Title"));
        JTextField title = new JTextField(5);
        c.add(title);

        c.add(new JLabel("Copyright Number"));
        JTextField copyright = new JTextField(5);
        c.add(copyright);

        c.add(new JLabel("Comments"));
        JTextArea comments = new JTextArea();
        c.add(comments);

        JButton submit = new JButton("Submit");
        c.add(submit);

        JButton readDB = new JButton("Read Database");
        c.add(readDB);

        c.add(new JLabel("Results"));
        JTextArea result = new JTextArea();
        JScrollPane scroll = new JScrollPane (result, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        c.add(scroll);



        try {
            // load database driver class
            Class.forName("com.mysql.cj.jdbc.Driver");
            // connect to database
            Connection connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/books", "root", "root");


            submit.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent event) {

                    try {
                        Class.forName("com.mysql.cj.jdbc.Driver");
                        // connect to database
                        Connection connection = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/books", "root", "root");
                        // create Statement to query database

                        sqlInsertbooks = connection.prepareStatement(
                                "INSERT INTO books (firstName, lastName, ISBN, title, copyright, comments) VALUES (?,?,?,?,?,?)");



                        sqlInsertbooks.setString(1, firstName.getText());
                        sqlInsertbooks.setString(2, lastName.getText());
                        sqlInsertbooks.setString(3, isbn.getText());
                        sqlInsertbooks.setString(4, title.getText());
                        sqlInsertbooks.setString(5, copyright.getText());
                        sqlInsertbooks.setString(6, comments.getText());
                        sqlInsertbooks.executeUpdate();

                    }catch (SQLException | ClassNotFoundException e) {
                        e.printStackTrace();}
                }
            });




            readDB.addActionListener(
                    new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            // create Statement to query database
                            Connection connection = null;
                            try {
                                connection = DriverManager.getConnection(
                                        "jdbc:mysql://localhost:3306/books", "root", "root");
                            } catch (SQLException ex) {
                                ex.printStackTrace();
                            }
                            Statement statement = null;
                            try {
                                statement = connection.createStatement();
                            } catch (SQLException ex) {
                                ex.printStackTrace();
                            }
                            ResultSet resultSet = null;
                            try {
                                resultSet = statement.executeQuery( "SELECT * FROM books" );
                            } catch (SQLException ex) {
                                ex.printStackTrace();
                            }


                            StringBuffer results = new StringBuffer();
                            ResultSetMetaData metaData = null;
                            try {
                                metaData = resultSet.getMetaData();
                            } catch (SQLException ex) {
                                ex.printStackTrace();
                            }
                            int numberOfColumns = 0;
                            try {
                                numberOfColumns = metaData.getColumnCount();
                            } catch (SQLException ex) {
                                ex.printStackTrace();
                            }

                            for ( int i = 1; i <= numberOfColumns; i++ ) {
                                try {
                                    results.append( metaData.getColumnName( i )
                                            + "\t" );
                                } catch (SQLException ex) {
                                    ex.printStackTrace();
                                }
                            }

                            results.append( "\n" );

                            while (true) {
                                try {
                                    if (!resultSet.next()) break;
                                } catch (SQLException ex) {
                                    ex.printStackTrace();
                                }

                                for ( int i = 1; i <= numberOfColumns; i++ ) {
                                    try {
                                        results.append( resultSet.getObject( i )
                                                + "\t" );
                                    } catch (SQLException ex) {
                                        ex.printStackTrace();
                                    }
                                }

                                results.append("\n");
                            }

// close statement and connection
                            try {
                                statement.close();
                                connection.close();
                            } catch (SQLException ex) {
                                ex.printStackTrace();
                            }

                            JTextArea textArea = new JTextArea(results.toString() );
                            Container container = getContentPane();
                            container.add( new JScrollPane( textArea ) );

                           setVisible( true );   // display window
                        }
                    }
            );



            setLayout(new GridLayout(9, 2, 0, 5));
            setSize(400, 400);
            setVisible(true);

            connection.close();

        }
        catch (SQLException | ClassNotFoundException sqlException ) {
            JOptionPane.showMessageDialog( null,
                    sqlException.getMessage(), "Database Error",
                    JOptionPane.ERROR_MESSAGE );

            System.exit( 1 );
        }


    }

    private static void createAndShowGUI() {
        //Create and set up the window.
        JFrame frame = new AddBook();
        //Display the window.
        frame.pack();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    public static void main (String args[])
    {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                AddBook window = new AddBook();
                window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            }
        });
    }
}